import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Task1 {

public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {

// FIX: Initialize result list to avoid the NullPointerException
List<LoanAccount> result = new ArrayList<>();

// FIX: To handle if account list is null in itself so as to prevent NullPointerException
if (accounts == null) {
return result;
}

for (LoanAccount account : accounts) {

// FIX: Skip null accounts and accounts with null due dates
// because as mentioned dueDate may be null for restructured accounts.
if (account != null && account.getDueDate() != null) {

if (account.getDueDate().before(new Date())) {

// FIX: Include overdue accounts with zero outstanding balance.
if (account.getOutstandingBalance() >= 0) {
result.add(account);
}
}
}
}
return result;
}
}