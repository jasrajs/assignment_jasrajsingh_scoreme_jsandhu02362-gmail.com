import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

public class ReportDAO {
// Assume dataSource is properly initialized and injected (e.g., via constructor or setter)
//Not Naming the classs as Task4 to abide by the contraints of the assignment 

private DataSource dataSource;

public List<ReportEntry> fetchMonthlyReport(String accountId,
int month,
int year)
throws SQLException {

// FIX: Use try-with-resources to automatically close Connection,
// PreparedStatement, and ResultSet to prevent connection pool exhaustion.
// Resources are closed in reverse order:
// ResultSet -> PreparedStatement -> Connection.
try (Connection conn = dataSource.getConnection();
PreparedStatement ps = conn.prepareStatement(
"SELECT * FROM report_entries " +
"WHERE account_id = ? AND MONTH(entry_date) = ? " +
"AND YEAR(entry_date) = ?")) {

ps.setString(1, accountId);
ps.setInt(2, month);
ps.setInt(3, year);

try (ResultSet rs = ps.executeQuery()) {

List<ReportEntry> entries = new ArrayList<>();

while (rs.next()) {
entries.add(mapRow(rs));
}

return entries;
}
}
}

}


