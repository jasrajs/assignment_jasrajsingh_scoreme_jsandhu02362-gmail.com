import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Task5 {

private static final Logger logger =
LoggerFactory.getLogger(Task5.class);

public ValidationResult validate(Document doc) {

try {

if (doc == null) {

// FIX: Expected validation failures should not print stack traces.
// Log validation issues usinhg SLF4J warning logs instead.
logger.warn("Validation failed: Document is null");

// FIX: we don't return null because callers may trigger
// NullPointerException  be coming while accessing the result.
return new ValidationResult(false);
}

String content = doc.extractContent();

if (content == null || content.isEmpty()) {

// FIX: Expected validation failures should not  be flooding logs
// with stack traces.
logger.warn("Validation failed: Empty content");

// FIX: Return failed validation result instead of null.
return new ValidationResult(false);
}

return runValidationRules(content);

} catch (Exception e) {

// FIX: I am replacing printStackTrace() with SLF4J error logging
// for unexpected runtime/system failures.
logger.error("Unexpected error during document validation", e);

// FIX: Don't return null because callers may trigger
// NullPointerException during batch validation.
return new ValidationResult(false);
}
}

public void validateBatch(List docs) {

for (Document doc : docs) {

try {

ValidationResult r = validate(doc);

// FIX: Prevent NullPointerException when validation fails.
if (r != null && r.isValid()) {
saveResult(r);
}

} catch (Exception e) {

// FIX: Don't silently swallow exceptions.
// Log batch-processing failures for troubleshooting.
logger.error("Failed to validate document in batch", e);
}
}
}
}
