import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class BankStatementBatchProcessor {
//Not naming the class as task3.java since it violates the contraints
private int processedCount = 0;

public void process(List<StatementRecord> records) {
ExecutorService executor = Executors.newFixedThreadPool(10);

for (StatementRecord record : records) {
executor.submit(() -> {
processRecord(record);

// FIX: processedCount++ is not atomic in multi-threaded environment.
// Multiple threads were updating the shared counter simultaneously,
// causing lost updates and inconsistent final counts.
//adding synchronization to ensure thread safety when updating the shared counter.
synchronized (this) {
processedCount++;
}
});
}

executor.shutdown();
executor.awaitTermination(5, TimeUnit.MINUTES);
}

public int getProcessedCount() {
return processedCount;
}
}
